// { "framework": "Vue" }
"use weex:vue";

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _Guide = __webpack_require__(1);

var _Guide2 = _interopRequireDefault(_Guide);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_Guide2.default.el = 'whatever';
new __vue_page__(_Guide2.default, { weex: weex, Vue: Vue });

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(2)
)

/* script */
__vue_exports__ = __webpack_require__(3)

/* template */
var __vue_template__ = __webpack_require__(11)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/Hanks/Codes/work/weex-vue-examples/src/pages/guide/Guide.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-70f8a4b5"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = {
  "size": {
    "width": "750",
    "height": "320"
  },
  "center": {
    "alignItems": "center",
    "justifyContent": "center"
  },
  "slider": {
    "width": "750",
    "height": "400",
    "boxShadow": "0 5px 10px rgba(0, 0, 0, 0.2)",
    "marginBottom": "10"
  },
  "slider-title": {
    "width": "750",
    "paddingTop": 0,
    "paddingRight": "30",
    "paddingBottom": "30",
    "paddingLeft": "30",
    "fontSize": "46",
    "textAlign": "center",
    "color": "#FFFFFF"
  },
  "indicator": {
    "position": "absolute",
    "left": 0,
    "right": 0,
    "bottom": 0,
    "width": "750",
    "height": "30",
    "itemSize": "12",
    "itemColor": "#DDDDDD",
    "itemSelectedColor": "rgb(0,180,255)"
  }
}

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(4);

var _stringify2 = _interopRequireDefault(_stringify);

var _Lesson = __webpack_require__(7);

var _Lesson2 = _interopRequireDefault(_Lesson);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  components: { Lesson: _Lesson2.default },
  computed: {
    chosenLesson: function chosenLesson() {
      return this.guideLessons[this.lessonIndex];
    }
  },
  created: function created() {
    console.log(' => lessons: (' + (0, _stringify2.default)(this.guideLessons) + ').');
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(5), __esModule: true };

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(6);
var $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
module.exports = function stringify(it) { // eslint-disable-line no-unused-vars
  return $JSON.stringify.apply($JSON, arguments);
};


/***/ }),
/* 6 */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.5.5' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(8)
)

/* script */
__vue_exports__ = __webpack_require__(9)

/* template */
var __vue_template__ = __webpack_require__(10)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/Hanks/Codes/work/weex-vue-examples/src/components/Lesson.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-712a3d30"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = {
  "center": {
    "alignItems": "center",
    "justifyContent": "center"
  },
  "title": {
    "fontSize": "60",
    "textAlign": "center",
    "marginTop": "60",
    "marginBottom": "60",
    "color": "#606060"
  },
  "lesson": {
    "borderBottomWidth": "1",
    "borderBottomStyle": "solid",
    "borderBottomColor": "#EEEEEE",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "lesson-zh": {
    "width": "600"
  },
  "lesson-en": {
    "width": "630"
  },
  "lesson-index": {
    "color": "#777777",
    "textAlign": "right",
    "paddingRight": "30"
  },
  "lesson-title": {
    "paddingTop": "35",
    "paddingBottom": "35"
  },
  "lesson-index-zh": {
    "fontSize": "46",
    "width": "120"
  },
  "lesson-title-zh": {
    "fontSize": "42",
    "width": "480"
  },
  "lesson-index-en": {
    "fontSize": "42",
    "width": "100"
  },
  "lesson-title-en": {
    "fontSize": "38",
    "width": "530"
  },
  "footer": {
    "height": "120",
    "paddingTop": "40"
  },
  "copyright": {
    "fontSize": "22",
    "color": "#A0A0A0",
    "textAlign": "center"
  }
}

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  props: ['mainColor', 'language', 'title', 'copyright', 'lessons']
};

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["wrapper"]
  }, [_c('div', {
    staticClass: ["center"]
  }, [_c('text', {
    staticClass: ["title"]
  }, [_vm._v(_vm._s(_vm.i18n(_vm.title)))])]), _vm._l((_vm.lessons), function(lesson, i) {
    return _c('div', {
      key: i,
      staticClass: ["center"]
    }, [_c('div', {
      class: ['lesson', ("lesson-" + _vm.language)]
    }, [_c('text', {
      class: ['lesson-index', ("lesson-index-" + _vm.language)]
    }, [_vm._v(_vm._s(i + 1) + ".")]), _c('text', {
      class: ['lesson-title', ("lesson-title-" + _vm.language)],
      style: {
        color: _vm.mainColor
      }
    }, [_vm._v(_vm._s(_vm.i18n(lesson.title)))])])])
  }), _c('div', {
    staticClass: ["footer", "center"]
  }, [_c('text', {
    staticClass: ["copyright"]
  }, [_vm._v(_vm._s(_vm.i18n(_vm.copyright)))])])], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: ["wrapper"]
  }, [_c('slider', {
    staticClass: ["slider"],
    attrs: {
      "autoPlay": "true"
    }
  }, [_vm._l((_vm.guideLessons), function(item, i) {
    return _c('div', {
      key: item.subject,
      staticClass: ["center"],
      style: {
        backgroundColor: item.posterBg
      },
      on: {
        "click": function($event) {
          _vm.lessonIndex = i
        }
      }
    }, [_c('div', {
      staticClass: ["center", "size"]
    }, [_c('image', {
      style: item.posterStyle,
      attrs: {
        "resize": "cover",
        "src": item.poster
      }
    })]), _c('text', {
      staticClass: ["slider-title"],
      style: {
        color: item.titleColor || item.mainColor
      }
    }, [_vm._v(_vm._s(_vm.i18n(item.title)))])])
  }), _c('indicator', {
    staticClass: ["indicator"]
  })], 2), _c('lesson', {
    attrs: {
      "mainColor": _vm.chosenLesson.mainColor,
      "language": _vm.language,
      "title": _vm.chosenLesson.title,
      "lessons": _vm.chosenLesson.lessons,
      "copyright": _vm.chosenLesson.copyright
    }
  })], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })
/******/ ]);