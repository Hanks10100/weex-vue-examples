// { "framework": "Vue" }
"use weex:vue";

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(3), __esModule: true };

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(2);

__webpack_require__(5);

__webpack_require__(6);

__webpack_require__(7);

__webpack_require__(8);

__webpack_require__(9);

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

App({
  globalData: {
    language: 'en',
    dict: {
      LANGUAGE: { en: 'Language', zh: '语言' }
    },
    examples: ['A', 'B', 'C'],
    aboutApp: 'app'
  },
  onLaunch: function onLaunch() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => app launch (' + (0, _stringify2.default)(args) + ')');
  },
  onShow: function onShow() {
    for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    console.log(' => app show (' + (0, _stringify2.default)(args) + ')');
  },
  onHide: function onHide() {
    console.log(' => app hide');
  }
});

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(4);
var $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
module.exports = function stringify(it) { // eslint-disable-line no-unused-vars
  return $JSON.stringify.apply($JSON, arguments);
};


/***/ }),
/* 4 */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.5.5' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page('landing', {
  data: function data(globalData) {
    return {
      language: globalData.language || 'en',
      pageKeys: [],
      menus: [[{ name: 'guide', title: 'Guide' }, { name: 'examples', title: 'Examples' }], [{ name: 'news', title: 'News' }, { name: 'about', title: 'About' }]]
    };
  },
  onLoad: function onLoad() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => landing page load (' + (0, _stringify2.default)(args) + ')');
  },
  onReady: function onReady() {
    for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    console.log(' => landing page ready (' + (0, _stringify2.default)(args) + ')');
  },
  onShow: function onShow() {
    for (var _len3 = arguments.length, args = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }

    console.log(' => landing page show (' + (0, _stringify2.default)(args) + ')');
  },
  onHide: function onHide() {
    console.log(' => landing page hide');
  },
  onUnload: function onUnload() {
    console.log(' => landing page unload');
  }
});

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page('about', {
  data: function data(globalData) {
    return {
      language: globalData.language || 'en',
      aboutApp: globalData.aboutApp
    };
  },
  onLoad: function onLoad() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => about page load (' + (0, _stringify2.default)(args) + ')');
  },
  onReady: function onReady() {
    for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    console.log(' => about page ready (' + (0, _stringify2.default)(args) + ')');
  },
  onShow: function onShow() {
    for (var _len3 = arguments.length, args = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }

    console.log(' => about page show (' + (0, _stringify2.default)(args) + ')');
  }
});

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page('examples', {
  data: function data(globalData) {
    return {
      language: globalData.language || 'en'
    };
  },
  onLoad: function onLoad() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => example page load (' + (0, _stringify2.default)(args) + ')');
  },
  onReady: function onReady() {
    console.log(' => example page ready');
  },
  onShow: function onShow() {
    console.log(' => example page show');
  },
  onHide: function onHide() {
    console.log(' => example page hide');
  },
  onUnload: function onUnload() {
    console.log(' => example page unload');
  }
});

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page('guide', {
  data: function data(globalData) {
    return {
      language: globalData.language || 'en'
    };
  },
  onLoad: function onLoad() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => guide page load (' + (0, _stringify2.default)(args) + ')');
  },
  onReady: function onReady() {
    console.log(' => guide page ready');
  },
  onShow: function onShow() {
    console.log(' => guide page show');
  },
  onHide: function onHide() {
    console.log(' => guide page hide');
  },
  onUnload: function onUnload() {
    console.log(' => guide page unload');
  }
});

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page('news', {
  data: function data(globalData) {
    return {
      language: globalData.language || 'en'
    };
  },
  onLoad: function onLoad() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => news page load (' + (0, _stringify2.default)(args) + ')');
  },
  onReady: function onReady() {
    console.log(' => news page ready');
  },
  onShow: function onShow() {
    console.log(' => news page show');
  },
  onHide: function onHide() {
    console.log(' => news page hide');
  },
  onUnload: function onUnload() {
    console.log(' => news page unload');
  }
});

/***/ })
/******/ ]);