App({
  globalData: {
    language: 'en',
    dict: {
      LANGUAGE: { en: 'Language', zh: '语言' }
    },
    examples: ['A', 'B', 'C'],
    aboutApp: 'app'
  },
  onLaunch () {
    console.log(' => app launch')
  },
  onShow () {
    console.log(' => app show')
  },
  onHide () {
    console.log(' => app hide')
  }
})

Page('landing', {
  data (globalData) {
    return {
      language: globalData.language || 'en',
      menus: [[
        { name: 'guide', title: 'Guide' },
        { name: 'examples', title: 'Examples' }
      ], [
        { name: 'news', title: 'News' },
        { name: 'about', title: 'About' }
      ]]
    }
  }
})

Page('about', {
  data (globalData) {
    return {
      language: globalData.language || 'en',
      aboutApp: globalData.aboutApp
    }
  },
  onLoad () {
  }
})
