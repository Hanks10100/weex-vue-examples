// { "framework": "Vue" }
"use weex:vue";

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _Examples = __webpack_require__(1);

var _Examples2 = _interopRequireDefault(_Examples);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_Examples2.default.el = 'whatever';
new __vue_page__(_Examples2.default, { weex: weex, Vue: Vue });

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(2)
)

/* script */
__vue_exports__ = __webpack_require__(3)

/* template */
var __vue_template__ = __webpack_require__(8)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/Hanks/Codes/work/weex-vue-examples/src/pages/examples/Examples.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-76eb2c1b"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = {
  "example-list": {
    "width": "750",
    "position": "absolute",
    "top": 0,
    "bottom": "100",
    "backgroundColor": "#F5F5F5"
  },
  "group-info": {
    "backgroundColor": "#FFFFFF"
  },
  "loading": {
    "flex": 1,
    "justifyContent": "center",
    "alignItems": "center"
  },
  "loading-text": {
    "fontSize": "60",
    "color": "#BBBBBB"
  },
  "group-title": {
    "width": "750",
    "paddingTop": "20",
    "paddingBottom": "35",
    "fontSize": "40",
    "textAlign": "center",
    "color": "#00B4FF",
    "backgroundImage": "linear-gradient(to bottom, #E3F5FB, #F9FEFF)"
  },
  "group-desc": {
    "fontSize": "28",
    "color": "#999999",
    "marginTop": "10",
    "marginLeft": "30",
    "marginRight": "40"
  },
  "doc-link": {
    "fontSize": "26",
    "color": "rgba(0,189,255,0.6)",
    "textAlign": "right",
    "marginTop": "10",
    "marginRight": "60",
    "marginBottom": "20"
  },
  "section": {
    "paddingBottom": "30"
  },
  "tabbar": {
    "width": "750",
    "position": "fixed",
    "bottom": 0,
    "height": "100",
    "flexDirection": "row",
    "justifyContent": "space-around",
    "alignItems": "flex-end",
    "backgroundColor": "#E6E6E6"
  },
  "tab-cell": {
    "width": "186",
    "height": "100",
    "borderTopWidth": "2",
    "borderTopStyle": "solid",
    "borderTopColor": "#DDDDDD",
    "justifyContent": "center",
    "backgroundColor": "#FCFCFC",
    "transitionProperty": "backgroundColor",
    "transitionDuration": 200
  },
  "@TRANSITION": {
    "tab-cell": {
      "property": "backgroundColor",
      "duration": 200
    },
    "tab-name": {
      "property": "color,fontSize",
      "duration": 100
    }
  },
  "active-tab-cell": {
    "borderTopColor": "rgba(0,189,255,0.8)",
    "backgroundColor": "#BDECFF"
  },
  "tab-name": {
    "textAlign": "center",
    "color": "#666666",
    "transitionProperty": "color,fontSize",
    "transitionDuration": 100
  },
  "tab-name-zh": {
    "fontSize": "36"
  },
  "tab-name-en": {
    "fontSize": "30"
  },
  "active-tab-name-zh": {
    "color": "#00B4FF",
    "fontSize": "42",
    "fontWeight": "bold"
  },
  "active-tab-name-en": {
    "color": "#00B4FF",
    "fontSize": "30",
    "fontWeight": "bold"
  }
}

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ExampleScroller = __webpack_require__(4);

var _ExampleScroller2 = _interopRequireDefault(_ExampleScroller);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  components: { ExampleScroller: _ExampleScroller2.default },
  computed: {
    showLoading: function showLoading() {
      return !this.examples.length;
    },
    tabs: function tabs() {
      return this.examples.map(function (group) {
        return {
          type: group.type,
          name: group.name
        };
      });
    },
    currentTab: function currentTab() {
      var _this = this;

      return this.examples.filter(function (tab) {
        return tab.type === _this.activeTab;
      })[0];
    }
  },
  methods: {
    toggleTab: function toggleTab(tabType) {
      this.activeTab = tabType;
      this.activeGroup = this.currentTab.group[0].type;
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(5)
)

/* script */
__vue_exports__ = __webpack_require__(6)

/* template */
var __vue_template__ = __webpack_require__(7)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/Hanks/Codes/work/weex-vue-examples/src/components/ExampleScroller.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-d9e80478"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = {
  "scroller": {
    "flexDirection": "row",
    "backgroundColor": "#FDFDFD",
    "paddingTop": "20",
    "paddingRight": "20",
    "paddingBottom": "20",
    "paddingLeft": "20",
    "height": "600"
  },
  "example-box": {
    "justifyContent": "space-between",
    "alignItems": "center",
    "paddingLeft": "6",
    "paddingRight": "6",
    "width": "310"
  },
  "screenshot": {
    "width": "270",
    "height": "422",
    "borderWidth": "1",
    "borderColor": "#DDDDDD"
  },
  "title": {
    "height": "75",
    "justifyContent": "center"
  },
  "title-text": {
    "fontSize": "32",
    "textAlign": "center",
    "color": "#606060",
    "paddingTop": "10",
    "paddingBottom": "10"
  },
  "example-tips": {
    "fontSize": "28",
    "textAlign": "center",
    "color": "#A5A5A5",
    "paddingTop": "10",
    "paddingBottom": "10"
  }
}

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  props: {
    language: {
      type: String,
      default: 'en'
    },
    examples: {
      type: Array,
      required: true
    }
  },
  data: function data() {
    return {
      VIEW_SOURCE: {
        en: 'view source',
        zh: '查看源码'
      }
    };
  }
};

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: ["scroller"],
    attrs: {
      "scrollDirection": "horizontal"
    }
  }, _vm._l((_vm.examples), function(example, i) {
    return _c('div', {
      key: i,
      staticClass: ["example-box"]
    }, [_c('div', {
      staticClass: ["title"]
    }, [_c('text', {
      staticClass: ["title-text"]
    }, [_vm._v(_vm._s(_vm.i18n(example.title)))])]), _c('div', {
      staticStyle: {
        alignItems: "center"
      }
    }, [_c('div', [_c('image', {
      staticClass: ["screenshot"],
      attrs: {
        "src": _vm.i18n(example.screenshot)
      }
    })]), _c('text', {
      staticClass: ["example-tips"]
    }, [_vm._v(_vm._s(_vm.i18n(_vm.VIEW_SOURCE)))])])])
  }))
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["wrapper"]
  }, [(_vm.examples && _vm.examples.length) ? _c('list', {
    staticClass: ["example-list"]
  }, [_vm._l((_vm.currentTab.group), function(exampleGroup) {
    return [(exampleGroup && exampleGroup.title || exampleGroup.name) ? _c('cell', {
      key: exampleGroup.type,
      ref: exampleGroup.type,
      refInFor: true,
      staticClass: ["group-info"],
      appendAsTree: true,
      attrs: {
        "append": "tree"
      }
    }, [_c('text', {
      staticClass: ["group-title"]
    }, [_vm._v(_vm._s(_vm.i18n(exampleGroup.title || exampleGroup.name)))]), (exampleGroup.desc) ? _c('text', {
      staticClass: ["group-desc"]
    }, [_vm._v(_vm._s(_vm.i18n(exampleGroup.desc)))]) : _vm._e(), (exampleGroup.desc && exampleGroup.docLink) ? _c('text', {
      staticClass: ["doc-link"]
    }, [_vm._v(_vm._s(_vm.i18n(_vm.dict.READ_MORE)) + " >>")]) : _vm._e()]) : _vm._e(), _c('cell', {
      key: exampleGroup.type + '-examples',
      staticClass: ["section"],
      appendAsTree: true,
      attrs: {
        "append": "tree"
      }
    }, [_c('example-scroller', {
      attrs: {
        "language": _vm.language,
        "examples": exampleGroup.examples
      }
    })], 1)]
  })], 2) : (_vm.showLoading) ? _c('div', {
    staticClass: ["loading"]
  }, [_c('text', {
    staticClass: ["loading-text"]
  }, [_vm._v("loading ...")])]) : _vm._e(), (_vm.tabs && _vm.tabs.length) ? _c('div', {
    staticClass: ["tabbar"]
  }, _vm._l((_vm.tabs), function(tab) {
    return _c('div', {
      key: tab.type,
      class: ['tab-cell', tab.type === _vm.activeTab ? 'active-tab-cell' : ''],
      on: {
        "click": function($event) {
          _vm.toggleTab(tab.type)
        }
      }
    }, [_c('text', {
      class: [
        'tab-name',
        ("tab-name-" + _vm.language),
        tab.type === _vm.activeTab ? ("active-tab-name-" + _vm.language) : ''
      ]
    }, [_vm._v(_vm._s(_vm.i18n(tab.name)))])])
  })) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })
/******/ ]);