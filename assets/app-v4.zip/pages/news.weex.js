// { "framework": "Vue" }
"use weex:vue";

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _News = __webpack_require__(1);

var _News2 = _interopRequireDefault(_News);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_News2.default.el = 'whatever';
new __vue_page__(_News2.default, { weex: weex, Vue: Vue });

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(2)
)

/* script */
__vue_exports__ = __webpack_require__(3)

/* template */
var __vue_template__ = __webpack_require__(7)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/Hanks/Codes/work/weex-vue-examples/src/pages/news/News.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-240b2d4a"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = {
  "list": {
    "backgroundColor": "#F1F1F1"
  },
  "refresh": {
    "width": "750",
    "alignItems": "center",
    "backgroundColor": "#808080"
  },
  "indicator-text": {
    "color": "#C5C5C5",
    "fontSize": "34",
    "paddingTop": "50",
    "paddingRight": "50",
    "paddingBottom": "50",
    "paddingLeft": "50",
    "textAlign": "center"
  },
  "cell": {
    "alignItems": "center"
  },
  "message-time": {
    "marginTop": "25",
    "justifyContent": "center"
  },
  "time-text": {
    "paddingTop": "5",
    "paddingBottom": "5",
    "paddingLeft": "18",
    "paddingRight": "18",
    "backgroundColor": "rgba(0,0,0,0.1)",
    "fontSize": "25",
    "borderRadius": "8",
    "color": "#FEFEFE"
  },
  "message-box": {
    "borderWidth": "1",
    "borderColor": "#DDDDDD",
    "borderRadius": "15",
    "backgroundColor": "#FFFFFF",
    "marginTop": "25",
    "marginBottom": "35",
    "backgroundColor:active": "#F8F8F8"
  },
  "related-article": {
    "borderTopWidth": "1",
    "borderTopColor": "#E6E6E6",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingTop": "10",
    "paddingBottom": "15",
    "paddingLeft": "30",
    "paddingRight": "20",
    "backgroundColor": "#FEFEFE"
  },
  "poster": {
    "width": "680",
    "height": "340",
    "backgroundColor": "#D2D2D2"
  },
  "title": {
    "width": "680",
    "paddingTop": "30",
    "paddingRight": "30",
    "paddingBottom": "30",
    "paddingLeft": "30",
    "fontSize": "38",
    "color": "#323232"
  },
  "shortcut": {
    "width": "80",
    "height": "80"
  },
  "subtitle": {
    "width": "550",
    "paddingRight": "25",
    "fontSize": "34",
    "color": "#454545"
  },
  "summary": {
    "width": "680",
    "marginTop": "-20",
    "paddingLeft": "30",
    "paddingRight": "30",
    "paddingBottom": "30",
    "fontSize": "28",
    "color": "#929292",
    "lines": 3
  }
}

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(4);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var modal = weex.requireModule('modal');
exports.default = {
  computed: {
    visibleNews: function visibleNews() {
      return this.news.slice(0, this.visibleCount);
    }
  },
  created: function created() {
    console.log(' => news in created: (' + (0, _stringify2.default)(this.news) + ').');
  },

  methods: {
    refresh: function refresh() {
      var _this = this;

      this.refreshing = true;
      this.refreshNote = this.dict.REFRESHING;
      this.$page.$emit('updateNews', true);
      this.$page.$on('newsUpdated', function () {
        _this.refreshing = false;
        modal.toast({ message: _this.i18n(_this.dict.UPDATED) });
        setTimeout(function () {
          _this.refreshNote = _this.dict.REFRESH;
        }, 500);
      });
    },
    loadmore: function loadmore() {
      var step = 4;
      var currentCount = this.visibleCount;
      this.visibleCount = Math.min(currentCount + step, this.news.length);
      modal.toast({
        message: this.visibleCount > currentCount ? this.i18n(this.dict.LOAD_MERE) : this.i18n(this.dict.NO_MORE_NEWS)
      });
    }
  }
};

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(5), __esModule: true };

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(6);
var $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
module.exports = function stringify(it) { // eslint-disable-line no-unused-vars
  return $JSON.stringify.apply($JSON, arguments);
};


/***/ }),
/* 6 */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.5.5' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('list', {
    staticClass: ["list"],
    attrs: {
      "loadmoreoffset": "10"
    },
    on: {
      "loadmore": _vm.loadmore
    }
  }, [_c('refresh', {
    staticClass: ["refresh"],
    attrs: {
      "display": _vm.refreshing ? 'show' : 'hide'
    },
    on: {
      "refresh": _vm.refresh
    }
  }, [_c('text', {
    staticClass: ["indicator-text"]
  }, [_vm._v(_vm._s(_vm.i18n(_vm.refreshNote)))])]), _vm._l((_vm.visibleNews), function(item, i) {
    return _c('cell', {
      key: i,
      staticClass: ["cell"],
      appendAsTree: true,
      attrs: {
        "append": "tree"
      }
    }, [(item.time) ? _c('div', {
      staticClass: ["message-time"]
    }, [_c('text', {
      staticClass: ["time-text"]
    }, [_vm._v(_vm._s(_vm.i18n(item.time)))])]) : _vm._e(), (item.type === 'article') ? _c('div', {
      staticClass: ["message-box"]
    }, [_c('div', {
      staticClass: ["article"]
    }, [_c('image', {
      staticClass: ["poster"],
      attrs: {
        "resize": "cover",
        "src": item.poster
      }
    }), _c('text', {
      staticClass: ["title"]
    }, [_vm._v(_vm._s(item.title))]), (item.summary) ? _c('text', {
      staticClass: ["summary"],
      attrs: {
        "lines": 3
      }
    }, [_vm._v(_vm._s(item.summary))]) : _vm._e(), _c('div', {
      staticClass: ["related"]
    }, _vm._l((item.related), function(sub) {
      return _c('div', {
        key: sub.title,
        staticClass: ["related-article"]
      }, [_c('text', {
        staticClass: ["subtitle"]
      }, [_vm._v(_vm._s(sub.title))]), _c('image', {
        staticClass: ["shortcut"],
        attrs: {
          "resize": "cover",
          "src": sub.poster
        }
      })])
    }))])]) : _vm._e()])
  })], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })
/******/ ]);