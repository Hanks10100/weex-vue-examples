// { "framework": "Vue" }
"use weex:vue";

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 8);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(10), __esModule: true };

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

// Thank's IE8 for his funny defineProperty
module.exports = !__webpack_require__(7)(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 2 */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.5.5' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.parseLanguage = parseLanguage;
exports.fetchData = fetchData;
var _requireModule = typeof requireModule === 'function' ? requireModule : typeof weex.requireModule === 'function' ? weex.requireModule : function (name) {
  return console.log('Can\'t require "' + name + '" module.');
};

var network = _requireModule('network');
var navigator = _requireModule('navigator');

var supportedLanguageRE = /(en|zh)\_?\w*/i;
function parseLanguage(language) {
  var match = supportedLanguageRE.exec(language + '');
  if (match && match[1]) {
    return match[1];
  }
  return '';
}

function fetchData(name) {
  var done = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : function () {};
  var fail = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function () {};

  try {
    network.request({
      url: 'http://dotwe.org/query/weex-playground-app',
      method: 'post',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      dataType: 'json',
      body: 'name=' + name
    }, function (res) {
      if (res.ok && res.data && res.data[name]) {
        done(res.data[name]);
      } else {
        fail(res);
      }
    }, function (error) {
      return fail(error);
    });
  } catch (err) {
    fail(err);
  }
}

var fetchExamples = exports.fetchExamples = function fetchExamples() {
  for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  return fetchData.apply(undefined, ['examples'].concat(args));
};
var fetchGuide = exports.fetchGuide = function fetchGuide() {
  for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    args[_key2] = arguments[_key2];
  }

  return fetchData.apply(undefined, ['guide'].concat(args));
};
var fetchAbout = exports.fetchAbout = function fetchAbout() {
  for (var _len3 = arguments.length, args = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    args[_key3] = arguments[_key3];
  }

  return fetchData.apply(undefined, ['about'].concat(args));
};
var fetchNews = exports.fetchNews = function fetchNews() {
  for (var _len4 = arguments.length, args = Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
    args[_key4] = arguments[_key4];
  }

  return fetchData.apply(undefined, ['news'].concat(args));
};

/***/ }),
/* 5 */
/***/ (function(module, exports) {

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(21);
var IE8_DOM_DEFINE = __webpack_require__(22);
var toPrimitive = __webpack_require__(24);
var dP = Object.defineProperty;

exports.f = __webpack_require__(1) ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(9);

__webpack_require__(27);

__webpack_require__(28);

__webpack_require__(29);

__webpack_require__(30);

__webpack_require__(31);

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

var _index = __webpack_require__(4);

var _mock = __webpack_require__(11);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var modal = requireModule('modal');

App({
  globalData: {
    language: 'zh',
    dict: {
      SCAN_QR_CODE: { en: 'Scan QR Code', zh: '扫描二维码' },
      LANGUAGE: { en: 'Language', zh: '语言' },
      LANGUAGE_TYPE: { en: 'English', zh: '简体中文' },
      FOLLOW_SYSTEM: { en: 'Follow System', zh: '跟随系统' },
      READ_MORE: { en: 'read more', zh: '查看更多' },
      REFRESH: { en: 'Release to refresh', zh: '释放刷新' },
      REFRESHING: { en: 'Fetching ...', zh: '正在加载……' },
      UPDATED: { en: 'Updated', zh: '已更新' },
      LOAD_MERE: { en: 'Load more', zh: '加载更多' },
      NO_MORE_NEWS: { en: 'No more news', zh: '到底了' }
    },
    examples: [],
    guideLessons: _mock.guideLessons,
    aboutApp: _mock.aboutApp,
    news: []
  },
  onLaunch: function onLaunch() {
    var _this = this;

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => app launch (' + (0, _stringify2.default)(args) + ')');
    modal.toast({ message: 'App Launched!' });

    (0, _index.fetchExamples)(function (result) {
      console.log(' => fetch examples: (' + (0, _stringify2.default)(result) + ')');
      _this.examples = result;
    }, function (error) {
      console.log(' => failed to fetch examples: (' + (0, _stringify2.default)(error) + ')');
    });
    (0, _index.fetchAbout)(function (result) {
      return _this.aboutApp = result;
    });
    (0, _index.fetchGuide)(function (result) {
      return _this.guideLessons = result;
    });
    // fetchNews(result => this.news = result)
    (0, _index.fetchNews)(function (result) {
      console.log(' => fetch news: (' + (0, _stringify2.default)(result) + ')');
      _this.news = result;
    }, function (error) {
      console.log(' => failed to fetch news: (' + (0, _stringify2.default)(error) + ')');
    });
  },
  onShow: function onShow() {
    console.log(' => app show');
  },
  onHide: function onHide() {
    console.log(' => app hide');
  }
});

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(2);
var $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
module.exports = function stringify(it) { // eslint-disable-line no-unused-vars
  return $JSON.stringify.apply($JSON, arguments);
};


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.aboutApp = exports.guideLessons = undefined;

var _sliders = __webpack_require__(12);

var _sliders2 = _interopRequireDefault(_sliders);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var guideLessons = exports.guideLessons = _sliders2.default;

var aboutApp = exports.aboutApp = [{
  title: { en: 'Weex Official Website', zh: 'Weex 官方网站' },
  link: {
    en: 'http://weex-project.io/',
    zh: 'http://weex-project.io/cn/'
  }
}, {
  title: { en: 'Apache Software Foundation', zh: 'Apache 软件基金会' },
  link: 'http://www.apache.org/'
}, {
  title: { en: 'Who is using Weex', zh: '谁在使用 Weex' },
  link: {
    en: 'http://weex-project.io/who-is-using-weex.html',
    zh: 'http://weex-project.io/cn/who-is-using-weex.html'
  }
}, {
  title: { en: 'Contribution', zh: '参与贡献' },
  link: {
    en: 'http://weex-project.io/guide/contributing.html',
    zh: 'http://weex-project.io/cn/guide/contributing.html'
  }
}, {
  title: { en: 'Release Note', zh: '版本变更' },
  link: {
    en: 'http://weex-project.io/releasenote.html',
    zh: 'http://weex-project.io/cn/releasenote.html'
  }
}, {
  title: { en: 'FAQ', zh: '常见问题' },
  link: {
    en: 'http://weex-project.io/faq.html',
    zh: 'http://weex-project.io/cn/faq.html'
  }
}];

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__(13);

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _ref, _ref2, _ref3;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = [{
  subject: 'weex',
  mainColor: '#00B4FF',
  title: { zh: '学习 Weex', en: 'Learn Weex' },
  poster: 'https://gw.alicdn.com/tfs/TB1.8Vdl9_I8KJjy0FoXXaFnVXa-3799-1615.png',
  posterBg: '#E5F7FF',
  posterStyle: {
    width: '650px',
    height: '304px'
  },
  copyright: {
    zh: '来自 http://weex-project.io/cn/',
    en: 'From http://weex-project.io/'
  },
  lessons: [{
    title: {
      zh: '快速入门',
      en: 'Getting Started'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/guide/index.html',
      en: 'http://weex-project.io/guide/index.html'
    }
  }, {
    title: {
      zh: '工作原理',
      en: 'How it Works'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/wiki/index.html',
      en: 'http://weex-project.io/wiki/index.html'
    }
  }, {
    title: {
      zh: 'Weex 中的前端框架',
      en: 'Front-end Frameworks'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/guide/front-end-frameworks.html',
      en: 'http://weex-project.io/guide/front-end-frameworks.html'
    }
  }, {
    title: {
      zh: '在 Weex 中使用 Vue.js',
      en: 'Use Vue.js on Weex'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/guide/use-vue.html',
      en: 'http://weex-project.io/guide/use-vue.html'
    }
  }, {
    title: {
      zh: '与 Web 平台的差异',
      en: 'Platform difference with Web'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/wiki/platform-difference.html',
      en: 'http://weex-project.io/wiki/platform-difference.html'
    }
  }, {
    title: {
      zh: '集成 Weex 到已有应用',
      en: 'Integrate to Your App'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/guide/integrate-to-your-app.html',
      en: 'http://weex-project.io/guide/integrate-to-your-app.html'
    }
  }, {
    title: {
      zh: '搭建开发环境',
      en: 'Set Up Dev Environment'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/guide/set-up-env.html',
      en: 'http://weex-project.io/guide/set-up-env.html'
    }
  }, {
    title: {
      zh: '通用样式',
      en: 'Common Styles'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/wiki/common-styles.html',
      en: 'http://weex-project.io/wiki/common-styles.html'
    }
  }, {
    title: {
      zh: '通用事件',
      en: 'Common Events'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/wiki/common-events.html',
      en: 'http://weex-project.io/wiki/common-events.html'
    }
  }, {
    title: {
      zh: 'Weex 实例变量',
      en: 'The "weex" Variable'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/references/weex-variable.html',
      en: 'http://weex-project.io/references/weex-variable.html'
    }
  }, {
    title: {
      zh: '内置组件',
      en: 'Built-in Components'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/references/components/index.html',
      en: 'http://weex-project.io/references/components/index.html'
    }
  }, {
    title: {
      zh: '内置模块',
      en: 'Built-in Modules'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/references/modules/index.html',
      en: 'http://weex-project.io/references/modules/index.html'
    }
  }, {
    title: {
      zh: '扩展 Android 组件/模块',
      en: 'Extend Android'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/guide/extend-android.html',
      en: 'http://weex-project.io/guide/extend-android.html'
    }
  }, {
    title: {
      zh: '扩展 iOS 组件/模块',
      en: 'Extend iOS'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/guide/extend-ios.html',
      en: 'http://weex-project.io/guide/extend-ios.html'
    }
  }, {
    title: {
      zh: '使用 weex-toolkit',
      en: 'Use weex-toolkit'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/tools/toolkit.html',
      en: 'http://weex-project.io/tools/toolkit.html'
    }
  }, {
    title: {
      zh: '如何参与贡献',
      en: 'How to Contribute'
    },
    docLink: {
      zh: 'http://weex-project.io/cn/contributing.html',
      en: 'http://weex-project.io/contributing.html'
    }
  }]
}, (_ref = {
  subject: 'vue',
  mainColor: '#42b983',
  title: { zh: '学习 Vue.js', en: 'Learn Vue.js' },
  poster: 'https://gw.alicdn.com/tfs/TB1J_uKcMMPMeJjy1XdXXasrXXa-400-400.png',
  posterBg: '#E7FBF2',
  posterStyle: {
    width: '300px',
    height: '300px'
  }
}, (0, _defineProperty3.default)(_ref, 'title', {
  zh: '学习 Vue.js',
  en: 'Learn Vue.js'
}), (0, _defineProperty3.default)(_ref, 'copyright', {
  zh: '来自 https://cn.vuejs.org/',
  en: 'From https://vuejs.org/'
}), (0, _defineProperty3.default)(_ref, 'lessons', [{
  title: {
    zh: 'Vue.js 是什么？',
    en: 'What is Vue.js ?'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/index.html',
    en: 'https://vuejs.org/v2/guide/index.html'
  }
}, {
  title: {
    zh: '单文件组件',
    en: 'Single File Components'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/single-file-components.html',
    en: 'https://vuejs.org/v2/guide/single-file-components.html'
  }
}, {
  title: {
    zh: '模板语法',
    en: 'Template Syntax'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/syntax.html',
    en: 'https://vuejs.org/v2/guide/syntax.html'
  }
}, {
  title: {
    zh: 'Class 与 Style 绑定',
    en: 'Class and Style Bindings'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/class-and-style.html',
    en: 'https://vuejs.org/v2/guide/class-and-style.html'
  }
}, {
  title: {
    zh: '条件渲染',
    en: 'Conditional Rendering'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/conditional.html',
    en: 'https://vuejs.org/v2/guide/conditional.html'
  }
}, {
  title: {
    zh: '列表渲染',
    en: 'List Rendering'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/list.html',
    en: 'https://vuejs.org/v2/guide/list.html'
  }
}, {
  title: {
    zh: '事件处理',
    en: 'Event Handling'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/events.html',
    en: 'https://vuejs.org/v2/guide/events.html'
  }
}, {
  title: {
    zh: '表单输入绑定',
    en: 'Form Input Bindings'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/forms.html',
    en: 'https://vuejs.org/v2/guide/forms.html'
  }
}, {
  title: {
    zh: 'Vue 实例',
    en: 'The Vue Instance'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/instance.html',
    en: 'https://vuejs.org/v2/guide/instance.html'
  }
}, {
  title: {
    zh: '在 Weex 中使用 Vue.js',
    en: 'Use Vue.js on Weex'
  },
  docLink: {
    zh: 'http://weex-project.io/cn/guide/use-vue.html',
    en: 'http://weex-project.io/guide/use-vue.html'
  }
}, {
  title: {
    zh: '混合（mixins）',
    en: 'Mixins'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/mixins.html',
    en: 'https://vuejs.org/v2/guide/mixins.html'
  }
}, {
  title: {
    zh: '过滤器（filters）',
    en: 'Filters'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/filters.html',
    en: 'https://vuejs.org/v2/guide/filters.html'
  }
}, {
  title: {
    zh: '插件（plugins）',
    en: 'Plugins'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/plugins.html',
    en: 'https://vuejs.org/v2/guide/plugins.html'
  }
}, {
  title: {
    zh: '自定义指令',
    en: 'Custom Directives'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/custom-directive.html',
    en: 'https://vuejs.org/v2/guide/custom-directive.html'
  }
}, {
  title: {
    zh: '状态管理',
    en: 'State Management'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/state-management.html',
    en: 'https://vuejs.org/v2/guide/state-management.html'
  }
}, {
  title: {
    zh: '深入响应式原理',
    en: 'Reactivity in Depth'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/reactivity.html',
    en: 'https://vuejs.org/v2/guide/reactivity.html'
  }
}, {
  title: {
    zh: '渲染函数',
    en: 'Render Functions'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/render-function.html',
    en: 'https://vuejs.org/v2/guide/render-function.html'
  }
}, {
  title: {
    zh: 'TypeScript 支持',
    en: 'TypeScript Support'
  },
  docLink: {
    zh: 'https://cn.vuejs.org/v2/guide/typescript.html',
    en: 'https://vuejs.org/v2/guide/typescript.html'
  }
}, {
  title: 'API',
  docLink: {
    zh: 'https://cn.vuejs.org/v2/api/',
    en: 'https://vuejs.org/v2/api/'
  }
}]), _ref), (_ref2 = {
  subject: 'javascript',
  mainColor: '#F7BD2A',
  title: { zh: '学习 Javascript', en: 'Learn Javascript' },
  poster: 'https://gw.alicdn.com/tfs/TB1bT98hMoQMeJjy0FpXXcTxpXa-1500-700.png',
  posterBg: '#FAF3EB',
  posterStyle: {
    width: '750px',
    height: '350px'
  }
}, (0, _defineProperty3.default)(_ref2, 'title', {
  zh: '学习 Javascript',
  en: 'Learn Javascript'
}), (0, _defineProperty3.default)(_ref2, 'copyright', {
  zh: '来自 MDN (Mozilla Developer Network)',
  en: 'From MDN (Mozilla Developer Network)'
}), (0, _defineProperty3.default)(_ref2, 'lessons', [{
  title: {
    zh: '什么是 Javascript ？',
    en: 'What is Javascript ?'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/First_steps/What_is_JavaScript',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/First_steps/What_is_JavaScript'
  }
}, {
  title: {
    zh: 'JavaScript基础',
    en: 'JavaScript basics'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/Getting_started_with_the_web/JavaScript_basics',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/JavaScript_basics'
  }
}, {
  title: {
    zh: '重新介绍 JavaScript',
    en: 'A re-introduction to JavaScript'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/A_re-introduction_to_JavaScript',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/A_re-introduction_to_JavaScript'
  }
}, {
  title: {
    zh: '语法和数据类型',
    en: 'Grammar and types'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Guide/Grammar_and_types#Variable_scope',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types#Variable_scope'
  }
}, {
  title: {
    zh: '数据类型和数据结构',
    en: 'Data types and data structures'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Data_structures',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Data_structures'
  }
}, {
  title: {
    zh: '变量',
    en: 'Variables'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/First_steps/Variables',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/First_steps/Variables'
  }
}, {
  title: {
    zh: '数字和操作符',
    en: 'Numbers and operators'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/First_steps/Math',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/First_steps/Math'
  }
}, {
  title: {
    zh: '字符串',
    en: 'Handling text'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/First_steps/Strings',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/First_steps/Strings'
  }
}, {
  title: {
    zh: '常用的 String 方法',
    en: 'Useful string methods'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/First_steps/Useful_string_methods',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/First_steps/Useful_string_methods'
  }
}, {
  title: {
    zh: '数组',
    en: 'Arrays'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/First_steps/Arrays',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/First_steps/Arrays'
  }
}, {
  title: {
    zh: '函数',
    en: 'Functions'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Guide/Functions',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions'
  }
}, {
  title: {
    zh: 'JavaScript 对象基础',
    en: 'JavaScript object basics'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/Objects/Basics',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Objects/Basics'
  }
}, {
  title: {
    zh: '使用对象',
    en: 'Working with objects'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Guide/Working_with_Objects',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_Objects'
  }
}, {
  title: {
    zh: '使用 JSON 数据',
    en: 'Working with JSON'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/Objects/JSON',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Objects/JSON'
  }
}, {
  title: {
    zh: '对象模型的细节',
    en: 'Details of the object model'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Guide/Details_of_the_Object_Model',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Details_of_the_Object_Model'
  }
}, {
  title: {
    zh: '对象原型',
    en: 'Object prototypes'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Objects/Object_prototypes',
    en: 'https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/Objects/Object_prototypes'
  }
}, {
  title: {
    zh: 'JavaScript 中的继承',
    en: 'Inheritance in JavaScript'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/Objects/Inheritance',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Objects/Inheritance'
  }
}, {
  title: {
    zh: '继承与原型链',
    en: 'Inheritance and the prototype chain'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Inheritance_and_the_prototype_chain',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Inheritance_and_the_prototype_chain'
  }
}, {
  title: {
    zh: '严格模式',
    en: 'Strict mode'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Strict_mode',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Strict_mode'
  }
}, {
  title: {
    zh: '内存管理',
    en: 'Memory Management'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Memory_Management',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Memory_Management'
  }
}, {
  title: {
    zh: '并发模型与事件循环',
    en: 'Concurrency model and Event Loop'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/EventLoop',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/EventLoop'
  }
}, {
  //   title: {
  //     zh: '索引集合类',
  //     en: 'Indexed collections'
  //   },
  //   docLink: {
  //     zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Guide/Indexed_collections',
  //     en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Indexed_collections'
  //   }
  // }, {
  //   title: {
  //     zh: '带键的集合',
  //     en: 'Keyed collections'
  //   },
  //   docLink: {
  //     zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Guide/Keyed_collections',
  //     en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Keyed_collections'
  //   }
  // }, {
  title: {
    zh: 'JavaScript 标准库',
    en: 'Standard built-in objects'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects',
    en: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects'
  }
}]), _ref2), (_ref3 = {
  subject: 'css',
  mainColor: '#F56FC6',
  title: { zh: '学习 CSS', en: 'Learn CSS' },
  titleColor: '#FFFFFF',
  poster: 'https://gw.alicdn.com/tfs/TB1k6anhMMPMeJjy1XdXXasrXXa-427-190.jpg',
  posterBg: '#FFA2DE',
  posterStyle: {
    width: '517px',
    height: '230px'
  }
}, (0, _defineProperty3.default)(_ref3, 'title', {
  zh: '学习 CSS',
  en: 'Learn CSS'
}), (0, _defineProperty3.default)(_ref3, 'copyright', {
  zh: '来自 MDN (Mozilla Developer Network)',
  en: 'From MDN (Mozilla Developer Network)'
}), (0, _defineProperty3.default)(_ref3, 'lessons', [{
  title: {
    zh: '什么是 CSS ？',
    en: 'What is CSS ?'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/Guide/CSS/Getting_started/What_is_CSS',
    en: 'https://developer.mozilla.org/en-US/docs/Web/Guide/CSS/Getting_started/What_is_CSS'
  }
}, {
  title: {
    zh: 'CSS 语法',
    en: 'CSS Syntax'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/CSS/Introduction_to_CSS/Syntax',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/CSS/Introduction_to_CSS/Syntax'
  }
}, {
  title: {
    zh: 'CSS的值和单位',
    en: 'CSS Values and Units'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/CSS/Introduction_to_CSS/Values_and_units',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/CSS/Introduction_to_CSS/Values_and_units'
  }
}, {
  title: {
    zh: '盒模型',
    en: 'The Box Model'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/CSS/Introduction_to_CSS/Box_model',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/CSS/Introduction_to_CSS/Box_model'
  }
}, {
  title: {
    zh: '盒模型的属性',
    en: 'Box Model Properties'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/CSS/CSS_Box_Model',
    en: 'https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Box_Model'
  }
}, {
  title: {
    zh: '定位布局',
    en: 'Positioning'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/CSS/CSS_layout/%E5%AE%9A%E4%BD%8Dx',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/positioning'
  }
}, {
  title: {
    zh: '定位布局的属性',
    en: 'CSS Positioning'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/CSS/CSS_Positioning',
    en: 'https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Positioning'
  }
}, {
  title: {
    zh: 'Flexbox 布局',
    en: 'Flexbox Layout'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Learn/CSS/CSS_layout/Flexbox',
    en: 'https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Flexbox'
  }
}, {
  title: {
    zh: 'Flexbox 布局的属性',
    en: 'CSS Flexible Box Layout'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/CSS/CSS_Flexible_Box_Layout',
    en: 'https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Flexible_Box_Layout'
  }
}, {
  title: {
    zh: 'Weex 中的通用样式',
    en: 'Common Styles in Weex'
  },
  docLink: {
    zh: 'http://weex-project.io/cn/references/common-style.html',
    en: 'http://weex-project.io/references/common-style.html'
  }
}, {
  title: {
    zh: 'Weex 中的文本样式',
    en: 'Text Styles in Weex'
  },
  docLink: {
    zh: 'http://weex-project.io/cn/references/text-style.html',
    en: 'http://weex-project.io/references/text-style.html'
  }
}, {
  title: {
    zh: '块格式化上下文(BFC)',
    en: 'Block Formatting Context'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/Guide/CSS/Block_formatting_context',
    en: 'https://developer.mozilla.org/en-US/docs/Web/Guide/CSS/Block_formatting_context'
  }
}, {
  title: {
    zh: '视觉格式化模型',
    en: 'Visual Formatting Model'
  },
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/Guide/CSS/Visual_formatting_model',
    en: 'https://developer.mozilla.org/en-US/docs/Web/Guide/CSS/Visual_formatting_model'
  }
}, {
  title: 'CSS Reference',
  docLink: {
    zh: 'https://developer.mozilla.org/zh-CN/docs/Web/CSS/Reference',
    en: 'https://developer.mozilla.org/en-US/docs/Web/CSS/Reference'
  }
}]), _ref3)];

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _defineProperty = __webpack_require__(14);

var _defineProperty2 = _interopRequireDefault(_defineProperty);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (obj, key, value) {
  if (key in obj) {
    (0, _defineProperty2.default)(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
};

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(15), __esModule: true };

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(16);
var $Object = __webpack_require__(2).Object;
module.exports = function defineProperty(it, key, desc) {
  return $Object.defineProperty(it, key, desc);
};


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(17);
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !__webpack_require__(1), 'Object', { defineProperty: __webpack_require__(6).f });


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(5);
var core = __webpack_require__(2);
var ctx = __webpack_require__(18);
var hide = __webpack_require__(20);
var has = __webpack_require__(26);
var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var IS_WRAP = type & $export.W;
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE];
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE];
  var key, own, out;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    if (own && has(exports, key)) continue;
    // export native or passed
    out = own ? target[key] : source[key];
    // prevent global pollution for namespaces
    exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]
    // bind timers to global for call from export context
    : IS_BIND && own ? ctx(out, global)
    // wrap global constructors for prevent change them in library
    : IS_WRAP && target[key] == out ? (function (C) {
      var F = function (a, b, c) {
        if (this instanceof C) {
          switch (arguments.length) {
            case 0: return new C();
            case 1: return new C(a);
            case 2: return new C(a, b);
          } return new C(a, b, c);
        } return C.apply(this, arguments);
      };
      F[PROTOTYPE] = C[PROTOTYPE];
      return F;
    // make static versions for prototype methods
    })(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // export proto methods to core.%CONSTRUCTOR%.methods.%NAME%
    if (IS_PROTO) {
      (exports.virtual || (exports.virtual = {}))[key] = out;
      // export proto methods to core.%CONSTRUCTOR%.prototype.%NAME%
      if (type & $export.R && expProto && !expProto[key]) hide(expProto, key, out);
    }
  }
};
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
module.exports = $export;


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

// optional / simple context binding
var aFunction = __webpack_require__(19);
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};


/***/ }),
/* 19 */
/***/ (function(module, exports) {

module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(6);
var createDesc = __webpack_require__(25);
module.exports = __webpack_require__(1) ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(3);
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = !__webpack_require__(1) && !__webpack_require__(7)(function () {
  return Object.defineProperty(__webpack_require__(23)('div'), 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(3);
var document = __webpack_require__(5).document;
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};


/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = __webpack_require__(3);
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};


/***/ }),
/* 25 */
/***/ (function(module, exports) {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),
/* 26 */
/***/ (function(module, exports) {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};


/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page('landing', {
  data: function data(globalData) {
    return {
      language: globalData.language || 'en',
      dict: globalData.dict,
      menus: [[{ name: 'guide', title: { en: 'Guide', zh: '教程' } }, { name: 'examples', title: { en: 'Examples', zh: '实例' } }], [{ name: 'news', title: { en: 'News', zh: '资讯' } }, { name: 'about', title: { en: 'About', zh: '关于' } }]]
    };
  },
  onLoad: function onLoad() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => landing page load (' + (0, _stringify2.default)(args) + ')');
  },
  onReady: function onReady() {
    for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    console.log(' => landing page ready (' + (0, _stringify2.default)(args) + ')');
  },
  onShow: function onShow() {
    for (var _len3 = arguments.length, args = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }

    console.log(' => landing page show (' + (0, _stringify2.default)(args) + ')');
  },
  onHide: function onHide() {
    console.log(' => landing page hide');
  },
  onUnload: function onUnload() {
    console.log(' => landing page unload');
  }
});

/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page('about', {
  data: function data(globalData) {
    return {
      language: globalData.language || 'en',
      dict: globalData.dict,
      aboutApp: globalData.aboutApp
    };
  },
  onLoad: function onLoad() {
    var _this = this;

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => about page load (' + (0, _stringify2.default)(args) + ')');
    console.log(' => data of about page: (' + (0, _stringify2.default)(this.aboutApp) + ')');
    this.$on('setLanguage', function (language) {
      console.log(' => will change language to: ' + language);
      _this.language = language;
      if (typeof getApp === 'function') {
        var app = getApp();
        app.language = language;
      } else {
        console.log(' => no getApp api, try to call $setGlobalData instead.');
        _this.$setGlobalData({ language: language });
      }
    });
  },
  onReady: function onReady() {
    console.log(' => about page ready');
  },
  onShow: function onShow() {
    console.log(' => about page show');
  }
});

/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page('examples', {
  data: function data(globalData) {
    return {
      language: globalData.language || 'en',
      examples: globalData.examples || [],
      dict: globalData.dict,
      activeTab: 'component',
      activeGroup: 'div'
    };
  },
  onLoad: function onLoad() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => examples page load (' + (0, _stringify2.default)(args) + ')');
    console.log(' => examples in onLoad: (' + (0, _stringify2.default)(this.examples) + ')');
  },
  onReady: function onReady() {
    console.log(' => examples page ready');
  },
  onShow: function onShow() {
    console.log(' => examples page show');
  },
  onHide: function onHide() {
    console.log(' => examples page hide');
  },
  onUnload: function onUnload() {
    console.log(' => examples page unload');
  }
});

/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page('guide', {
  data: function data(globalData) {
    return {
      language: globalData.language || 'en',
      guideLessons: globalData.guideLessons || [],
      lessonIndex: 0
    };
  },
  onLoad: function onLoad() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => guide page load (' + (0, _stringify2.default)(args) + ')');
  },
  onReady: function onReady() {
    console.log(' => guide page ready');
  },
  onShow: function onShow() {
    console.log(' => guide page show');
  },
  onHide: function onHide() {
    console.log(' => guide page hide');
  },
  onUnload: function onUnload() {
    console.log(' => guide page unload');
  }
});

/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(0);

var _stringify2 = _interopRequireDefault(_stringify);

var _index = __webpack_require__(4);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page('news', {
  data: function data(globalData) {
    return {
      language: globalData.language || 'en',
      dict: globalData.dict,
      news: globalData.news || [],
      refreshNote: globalData.dict.REFRESH,
      refreshing: false,
      visibleCount: 6
    };
  },
  onLoad: function onLoad() {
    var _this = this;

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    console.log(' => news page load (' + (0, _stringify2.default)(args) + ')');
    console.log(' => news in onLoad: (' + (0, _stringify2.default)(this.news) + ').');
    this.$on('updateNews', function (shouldFeedback) {
      (0, _index.fetchNews)(function (res) {
        if (Array.isArray(res.news)) {
          _this.news = res.news;
          _this.$setGlobalData({ news: _this.news });
          shouldFeedback && _this.$emit('newsUpdated', res.news);
        }
      });
    });
  },
  onReady: function onReady() {
    console.log(' => news page ready');
  },
  onShow: function onShow() {
    console.log(' => news page show');
  },
  onHide: function onHide() {
    console.log(' => news page hide');
  },
  onUnload: function onUnload() {
    console.log(' => news page unload');
  }
});

/***/ })
/******/ ]);